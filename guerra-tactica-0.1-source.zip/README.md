# Guerra Táctica — prototipo Android 0.1

Proyecto Android nativo en Java, sin motor de juego ni librerías externas. La aplicación dibuja el mapa con una `View` propia y separa las reglas en clases Java que no dependen de Android. Esto mantiene el proyecto pequeño y editable desde Codex, y deja abierta la incorporación posterior de recursos visuales o un renderizador más avanzado.

## Ejecutar y compilar

El proyecto requiere Android SDK con plataforma 35 y Gradle/Android Gradle Plugin 8.7.3. Desde un entorno Android remoto que tenga esas herramientas:

```bash
gradle :app:assembleDebug
```

El APK resultante será `app/build/outputs/apk/debug/app-debug.apk`. En el workspace usado para esta entrega no se detectaron `gradle`, `adb`, `javac` ni un Android SDK, por lo que no se generó APK aquí.

Para compilar sin una computadora personal, subí este proyecto a un repositorio GitHub desde el navegador del teléfono y ejecutá manualmente el workflow `Android debug APK` en la pestaña Actions. El workflow instala Java, SDK Android y Gradle en un runner remoto, y deja `app-debug.apk` como artefacto descargable al teléfono.

## Controles

- Toque una ficha propia para seleccionarla y ver casillas alcanzables.
- Toque `MOVER`, elija una casilla y luego `CONFIRMAR`.
- `RÁPIDO` reduce el costo temporal del movimiento al 50% y suma fatiga.
- `ATACAR`, toque una ficha enemiga cercana y confirme.
- `DEFENDER` consume 60 s y protege frente al próximo turno enemigo.
- `REPLEGAR` permite hasta cinco casillas y consume 120 s.
- Arrastre de un dedo desplaza el mapa; pellizco acerca o aleja.
- `CANCELAR`, `TERMINAR TURNO`, `REINICIAR` y `PAUSA` están en el panel lateral.

Las casillas equivalen a 20 m virtuales. Los costos, alcance, probabilidades y condiciones están en `GameConfig.java`.

## Pruebas

Las reglas puras se comprueban sin Android SDK con:

```bash
./scripts/run_model_checks.sh
```

Las pruebas cubren costos de terreno, movimiento ortogonal, presupuesto, obstáculos, recarga de turno, capacidad porcentual y control por ocupación. No se pudo ejecutar una prueba de interfaz ni de dispositivo en este entorno porque no hay SDK/ADB.
