package com.tactica.guerra.model;

/** Todos los valores de equilibrio de la versión 0.1 están centralizados aquí. */
public final class GameConfig {
    private GameConfig() {}
    public static final int COLUMNS = 24;
    public static final int ROWS = 16;
    public static final int METERS_PER_CELL = 20;
    public static final int TURN_SECONDS = 120;
    public static final int ATTACK_SECONDS = 60;
    public static final int DEFEND_SECONDS = 60;
    public static final int RETREAT_SECONDS = 120;
    public static final int ATTACK_RANGE = 3;
    public static final int RETREAT_MAX_CELLS = 5;
    public static final int FAST_SPEED_BONUS_PERCENT = 50;
    public static final int FAST_FATIGUE = 20;
    public static final int DEFENSE_REDUCTION_PERCENT = 20;
    public static final int BASE_HIT_PERCENT = 60;
    public static final int MIN_DAMAGE_PERCENT = 5;
    public static final int MAX_DAMAGE_PERCENT = 15;
    public static final int WIN_OBJECTIVES = 2;
    public static final int WIN_CONSECUTIVE_TURNS = 2;

    public static int terrainCost(Terrain terrain) {
        switch (terrain) {
            case ROAD: return 20;
            case PLAIN: return 30;
            case GRASS: return 30;
            case FOREST: return 45;
            case HILL: return 45;
            case DIFFICULT: return 60;
            default: return Integer.MAX_VALUE;
        }
    }
}
