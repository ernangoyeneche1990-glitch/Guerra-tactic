package com.tactica.guerra.model;

public class Objective {
    public enum Control { NEUTRAL, PLAYER, ENEMY, CONTESTED }
    public final String id;
    public final int x, y;
    public Control control = Control.NEUTRAL;
    public Objective(String id, int x, int y) { this.id = id; this.x = x; this.y = y; }
    public String controlLabel() {
        switch (control) {
            case PLAYER: return "JUGADOR";
            case ENEMY: return "ENEMIGO";
            case CONTESTED: return "DISPUTADO";
            default: return "NEUTRAL";
        }
    }
}
