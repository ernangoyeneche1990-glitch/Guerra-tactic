package com.tactica.guerra.rules;

import com.tactica.guerra.model.GameConfig;
import com.tactica.guerra.model.Terrain;

public class GridMap {
    private final Terrain[][] cells = new Terrain[GameConfig.ROWS][GameConfig.COLUMNS];

    public GridMap() {
        for (int y = 0; y < GameConfig.ROWS; y++) for (int x = 0; x < GameConfig.COLUMNS; x++)
            cells[y][x] = Terrain.PLAIN;
        for (int x = 0; x < GameConfig.COLUMNS; x++) cells[7][x] = Terrain.ROAD;
        for (int y = 1; y < 15; y++) cells[y][12] = Terrain.ROAD;
        paint(Terrain.GRASS, 0, 0, 8, 7);
        paint(Terrain.FOREST, 14, 1, 5, 5);
        paint(Terrain.FOREST, 3, 9, 4, 5);
        paint(Terrain.HILL, 9, 10, 5, 5);
        paint(Terrain.DIFFICULT, 17, 11, 5, 4);
        // Caminos atraviesan los sectores decorativos, como rutas de tránsito.
        for (int x = 0; x < GameConfig.COLUMNS; x++) cells[7][x] = Terrain.ROAD;
        for (int y = 0; y < GameConfig.ROWS; y++) cells[y][12] = Terrain.ROAD;
        block(9, 5); block(10, 5); block(9, 6); block(10, 6);
        block(15, 8); block(16, 8); block(19, 10); block(20, 10);
        block(7, 13); block(8, 13); block(21, 4);
    }

    private void paint(Terrain terrain, int startX, int startY, int width, int height) {
        for (int y = startY; y < startY + height && y < GameConfig.ROWS; y++)
            for (int x = startX; x < startX + width && x < GameConfig.COLUMNS; x++) cells[y][x] = terrain;
    }
    private void block(int x, int y) { if (inBounds(x, y)) cells[y][x] = Terrain.BLOCKED; }
    public boolean inBounds(int x, int y) { return x >= 0 && y >= 0 && x < GameConfig.COLUMNS && y < GameConfig.ROWS; }
    public Terrain terrainAt(int x, int y) { return inBounds(x, y) ? cells[y][x] : Terrain.BLOCKED; }
    public boolean passable(int x, int y) { return inBounds(x, y) && terrainAt(x, y) != Terrain.BLOCKED; }
}
