package com.tactica.guerra.ui;

import android.content.Context;
import android.graphics.*;
import android.view.MotionEvent;
import android.view.View;
import com.tactica.guerra.model.*;
import com.tactica.guerra.rules.*;
import java.util.*;

/** Vista única, nativa y táctil del prototipo. La lógica vive en GameState y rules. */
public class TacticalGameView extends View {
    private enum Mode { IDLE, MOVE, ATTACK, RETREAT }
    private final GameState game = new GameState();
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Map<String, RectF> buttons = new LinkedHashMap<>();
    private UnitModel selected;
    private UnitModel previewTarget;
    private List<int[]> previewPath;
    private int previewCost;
    private Set<String> reachable = new HashSet<>();
    private Mode mode = Mode.IDLE;
    private boolean fastMove = false;
    private boolean paused = false;
    private boolean animating = false;
    private float zoom = 1f, panX = 0, panY = 0;
    private float downX, downY, lastX, lastY, pinchDistance;
    private boolean dragging, pinching;
    private float pinchZoom;
    private float tile, originX, originY, mapWidth;

    private final int dark = Color.rgb(25, 32, 30), panel = Color.rgb(36, 45, 41), cream = Color.rgb(237, 232, 207);
    public TacticalGameView(Context context) {
        super(context); text.setTypeface(Typeface.create("sans", Typeface.NORMAL)); setFocusable(true);
    }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas); layoutMap();
        canvas.drawColor(dark);
        drawMap(canvas); drawTopBar(canvas); drawSidebar(canvas);
        if (paused) { paint.setColor(0xBB101412); canvas.drawRect(0, 0, getWidth(), getHeight(), paint); centered(canvas, "PAUSA", getWidth()/2f, getHeight()/2f, 34, Color.WHITE); }
    }

    private void layoutMap() {
        mapWidth = getWidth() * 0.72f;
        float availableW = mapWidth - 24, availableH = getHeight() - 64;
        tile = Math.min(availableW / GameConfig.COLUMNS, availableH / GameConfig.ROWS) * zoom;
        originX = (mapWidth - tile * GameConfig.COLUMNS) / 2f + panX;
        originY = 54 + (getHeight() - 54 - tile * GameConfig.ROWS) / 2f + panY;
    }

    private void drawMap(Canvas c) {
        paint.setStyle(Paint.Style.FILL); paint.setColor(Color.rgb(130, 145, 102)); c.drawRect(0, 52, mapWidth, getHeight(), paint);
        for (int y=0; y<GameConfig.ROWS; y++) for (int x=0; x<GameConfig.COLUMNS; x++) {
            float l=originX+x*tile, t=originY+y*tile; Terrain terrain=game.map.terrainAt(x,y);
            paint.setColor(terrainColor(terrain)); c.drawRect(l, t, l+tile+1, t+tile+1, paint);
            if (terrain == Terrain.FOREST && tile > 12) drawTree(c, l+tile*.5f, t+tile*.55f, tile*.22f);
            if (terrain == Terrain.HILL && tile > 12) { paint.setColor(0x33715B42); c.drawCircle(l+tile*.55f,t+tile*.55f,tile*.32f,paint); }
            if (terrain == Terrain.BLOCKED) drawRock(c,l+tile*.5f,t+tile*.5f,tile*.28f);
            paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(1); paint.setColor(0x55706F5E); c.drawRect(l,t,l+tile,t+tile,paint); paint.setStyle(Paint.Style.FILL);
            if (reachable.contains(PathFinder.key(x,y))) { paint.setColor(0x668BCB70); c.drawRect(l+2,t+2,l+tile-2,t+tile-2,paint); }
        }
        if (previewPath != null && !previewPath.isEmpty()) {
            paint.setColor(0xCCFFF0A0); paint.setStrokeWidth(Math.max(3, tile*.12f)); paint.setStyle(Paint.Style.STROKE);
            Path p = new Path(); p.moveTo(centerX(selected.x), centerY(selected.y));
            for (int[] cell : previewPath) p.lineTo(centerX(cell[0]), centerY(cell[1])); c.drawPath(p,paint); paint.setStyle(Paint.Style.FILL);
        }
        for (Objective o : game.objectives) drawObjective(c,o);
        for (UnitModel unit : game.units) if (unit.operationalCapacity > 0) drawUnit(c,unit);
    }

    private int terrainColor(Terrain t) {
        switch(t) {
            case ROAD: return Color.rgb(183, 158, 107); case PLAIN: return Color.rgb(166, 157, 113);
            case GRASS: return Color.rgb(119, 151, 91); case FOREST: return Color.rgb(67, 105, 69);
            case HILL: return Color.rgb(143, 126, 88); case DIFFICULT: return Color.rgb(119, 100, 76);
            default: return Color.rgb(71, 75, 69);
        }
    }
    private void drawTree(Canvas c,float x,float y,float r) { paint.setColor(0xFF263F2D); c.drawCircle(x,y-r*.5f,r,paint); paint.setColor(0xFF6A4A2C); c.drawRect(x-r*.14f,y,x+r*.14f,y+r*1.1f,paint); }
    private void drawRock(Canvas c,float x,float y,float r) { paint.setColor(0xFF303532); c.drawOval(x-r,y-r*.65f,x+r,y+r*.65f,paint); paint.setColor(0xFF70786D); c.drawOval(x-r*.55f,y-r*.45f,x+r*.2f,y,paint); }
    private void drawObjective(Canvas c,Objective o) {
        int color=o.control==Objective.Control.PLAYER?0xFF4D9BEA:o.control==Objective.Control.ENEMY?0xFFE55E5E:o.control==Objective.Control.CONTESTED?0xFFE0B34B:0xFFD8D8C8;
        paint.setColor(color); paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(Math.max(2,tile*.06f)); c.drawCircle(centerX(o.x),centerY(o.y),tile*.34f,paint); paint.setStyle(Paint.Style.FILL);
        centered(c,o.id,centerX(o.x),centerY(o.y)+tile*.58f,Math.max(10,tile*.18f),Color.WHITE);
    }
    private void drawUnit(Canvas c,UnitModel u) {
        float l=originX+u.x*tile+tile*.12f,t=originY+u.y*tile+tile*.12f,r=originX+(u.x+1)*tile-tile*.12f,b=originY+(u.y+1)*tile-tile*.12f;
        int base=u.side==UnitModel.Side.PLAYER?Color.rgb(82,136,74):Color.rgb(159,73,66);
        paint.setColor(base); c.drawRoundRect(l,t,r,b,tile*.14f,tile*.14f,paint);
        if (u==selected) { paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(Math.max(3,tile*.08f)); paint.setColor(Color.YELLOW); c.drawRoundRect(l-2,t-2,r+2,b+2,tile*.14f,tile*.14f,paint); paint.setStyle(Paint.Style.FILL); }
        centered(c,u.type.equals("Apoyo")?"A":"T",(l+r)/2,(t+b)/2,Math.max(14,tile*.36f),Color.BLACK);
        if (u.defending) { paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(2); paint.setColor(Color.CYAN); c.drawCircle((l+r)/2,(t+b)/2,tile*.42f,paint); paint.setStyle(Paint.Style.FILL); }
        centered(c,Math.round(u.operationalCapacity)+"%",(l+r)/2,b+tile*.16f,Math.max(9,tile*.16f),Color.WHITE);
    }
    private float centerX(int x) { return originX+(x+.5f)*tile; }
    private float centerY(int y) { return originY+(y+.5f)*tile; }

    private void drawTopBar(Canvas c) {
        paint.setColor(0xEE18211E); c.drawRect(0,0,getWidth(),52,paint);
        String status="TURNO "+game.turn+"   |   "+(game.activeSide==UnitModel.Side.PLAYER?"JUGADOR":"ENEMIGO")+"   |   OBJETIVOS "+game.controlledByPlayer()+"/"+GameConfig.WIN_OBJECTIVES;
        label(c,status,18,33,18,cream);
        if (game.gameWon) label(c,"VICTORIA",mapWidth-145,33,18,Color.rgb(255,215,80));
    }
    private void drawSidebar(Canvas c) {
        buttons.clear(); paint.setColor(panel); c.drawRect(mapWidth,0,getWidth(),getHeight(),paint);
        float x=mapWidth+18,w=getWidth()-mapWidth-36; float y=68;
        if (selected != null) {
            label(c,selected.name,x,y,19,cream); label(c,selected.sideLabel()+" · "+selected.type,x,y+24,13,0xFFB7C5B6);
            label(c,"Capacidad: "+Math.round(selected.operationalCapacity)+"%  |  Dotación: "+selected.originalStrength,x,y+46,13,cream);
            label(c,"Munición: "+selected.ammunition+"   Fatiga: "+selected.fatigue+"   Moral: "+selected.morale,x,y+66,13,cream);
            label(c,"Tiempo: "+selected.timeRemaining+" s",x,y+91,17,selected.timeRemaining>0?Color.WHITE:0xFFE57373);
            if (selected.defending) label(c,"DEFENSA ACTIVA",x,y+113,13,Color.CYAN);
            y += selected.defending ? 136 : 116;
        } else { label(c,"Ninguna ficha seleccionada",x,y,16,cream); y+=42; }
        if (previewPath != null && !previewPath.isEmpty()) {
            label(c,"PREVISUALIZACIÓN",x,y,14,Color.YELLOW); label(c,"Distancia: "+previewPath.size()*GameConfig.METERS_PER_CELL+" m",x,y+22,14,cream);
            label(c,"Casillas: "+previewPath.size()+"   Tiempo: "+previewCost+" s",x,y+42,14,cream);
            label(c,"Restante: "+(selected.timeRemaining-previewCost)+" s",x,y+62,14,cream);
            y+=82;
        } else if (previewTarget != null) { label(c,"Objetivo: "+previewTarget.name,x,y,14,Color.YELLOW); label(c,"Alcance: "+GameState.distance(selected,previewTarget)+" casillas",x,y+22,14,cream); y+=44; }
        float gap=7, colW=(w-gap)/2f, buttonH=44;
        actionButton(c,"MOVER",x,y,colW,buttonH,mode==Mode.MOVE); actionButton(c,"ATACAR",x+colW+gap,y,colW,buttonH,mode==Mode.ATTACK);
        actionButton(c,"DEFENDER",x,y+buttonH+gap,colW,buttonH,false); actionButton(c,"REPLEGAR",x+colW+gap,y+buttonH+gap,colW,buttonH,mode==Mode.RETREAT);
        float quickY=y+2*(buttonH+gap); actionButton(c,fastMove?"RÁPIDO ✓":"RÁPIDO",x,quickY,w,buttonH*.8f,fastMove);
        float commandY=getHeight()-108, commandH=44;
        actionButton(c,"CONFIRMAR",x,commandY,colW,commandH,previewPath!=null||previewTarget!=null); actionButton(c,"CANCELAR",x+colW+gap,commandY,colW,commandH,false);
        float smallW=(w-2*gap)/3f, bottomY=commandY+commandH+gap;
        actionButton(c,"TERMINAR TURNO",x,bottomY,smallW,commandH*.86f,false); actionButton(c,"REINICIAR",x+smallW+gap,bottomY,smallW,commandH*.86f,false); actionButton(c,paused?"CONTINUAR":"PAUSA",x+2*(smallW+gap),bottomY,smallW,commandH*.86f,false);
        label(c,game.lastMessage,x,Math.min(commandY-8,quickY+buttonH+18),12,0xFFD3D7C9);
    }
    private void actionButton(Canvas c,String title,float x,float y,float w,float h,boolean active) {
        if (y<54 || y+h>getHeight()-2) return; RectF r=new RectF(x,y,x+w,y+h); buttons.put(title,r);
        paint.setColor(active?Color.rgb(103,139,80):Color.rgb(61,76,67)); c.drawRoundRect(r,9,9,paint); paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(1); paint.setColor(0xFF9CAF91); c.drawRoundRect(r,9,9,paint); paint.setStyle(Paint.Style.FILL);
        centered(c,title,x+w/2,y+h/2+5,Math.max(12,Math.min(16,h*.32f)),Color.WHITE);
    }
    private void label(Canvas c,String value,float x,float y,float size,int color) { text.setTextSize(size); text.setColor(color); text.setTypeface(Typeface.create("sans",Typeface.NORMAL)); c.drawText(value,x,y,text); }
    private void centered(Canvas c,String value,float x,float y,float size,int color) { text.setTextSize(size); text.setColor(color); text.setTypeface(Typeface.create("sans",Typeface.BOLD)); c.drawText(value,x-text.measureText(value)/2,y-text.ascent()/2-text.descent()/2,text); }

    @Override public boolean onTouchEvent(MotionEvent e) {
        if (e.getActionMasked()==MotionEvent.ACTION_DOWN) { downX=lastX=e.getX(); downY=lastY=e.getY(); dragging=false; pinching=false; return true; }
        if (e.getActionMasked()==MotionEvent.ACTION_POINTER_DOWN && e.getPointerCount()>=2) { pinching=true; pinchDistance=distance(e); pinchZoom=zoom; return true; }
        if (e.getActionMasked()==MotionEvent.ACTION_MOVE) {
            if (e.getPointerCount()>=2) { float d=distance(e); if (pinchDistance>1) zoom=Math.max(.65f,Math.min(2.1f,pinchZoom*d/pinchDistance)); invalidate(); return true; }
            float dx=e.getX()-lastX,dy=e.getY()-lastY; if (Math.hypot(e.getX()-downX,e.getY()-downY)>12) dragging=true;
            if (dragging && !pinching) { panX+=dx; panY+=dy; invalidate(); } lastX=e.getX(); lastY=e.getY(); return true;
        }
        if (e.getActionMasked()==MotionEvent.ACTION_UP) { if (!dragging && !pinching) tap(e.getX(),e.getY()); pinching=false; return true; }
        return true;
    }
    private float distance(MotionEvent e) { if(e.getPointerCount()<2)return 0; return (float)Math.hypot(e.getX(0)-e.getX(1),e.getY(0)-e.getY(1)); }
    private void tap(float x,float y) {
        if (animating) return;
        for (Map.Entry<String,RectF> entry:buttons.entrySet()) if(entry.getValue().contains(x,y)) { button(entry.getKey()); return; }
        if (x>=mapWidth || y<54) return; int[] cell=cellAt(x,y); if(cell==null)return;
        UnitModel hit=game.unitAt(cell[0],cell[1]);
        if (mode==Mode.ATTACK && hit!=null && selected!=null && hit.side==UnitModel.Side.ENEMY) { previewTarget=hit; previewPath=null; invalidate(); return; }
        if (hit!=null) { selected=hit; previewPath=null; previewTarget=null; mode=Mode.IDLE; reachable.clear(); if(hit.side==game.activeSide) calculateReachable(); invalidate(); return; }
        if (selected!=null && (mode==Mode.MOVE || mode==Mode.RETREAT || mode==Mode.IDLE)) { if(mode==Mode.IDLE)mode=Mode.MOVE; preview(cell[0],cell[1]); invalidate(); }
    }
    private int[] cellAt(float sx,float sy) { int x=(int)Math.floor((sx-originX)/tile), y=(int)Math.floor((sy-originY)/tile); return game.map.inBounds(x,y)?new int[]{x,y}:null; }
    private void calculateReachable() { reachable.clear(); if(selected==null||selected.side!=UnitModel.Side.PLAYER||game.activeSide!=UnitModel.Side.PLAYER)return; for(int y=0;y<GameConfig.ROWS;y++)for(int x=0;x<GameConfig.COLUMNS;x++) if(PathFinder.find(game.map,selected.x,selected.y,x,y,selected.timeRemaining,game.occupiedExcept(selected),fastMove&&mode==Mode.MOVE,mode==Mode.RETREAT?GameConfig.RETREAT_MAX_CELLS:0)!=null)reachable.add(PathFinder.key(x,y)); }
    private void preview(int x,int y) { if(selected==null||selected.side!=UnitModel.Side.PLAYER)return; int budget=selected.timeRemaining; if(mode==Mode.RETREAT)budget=Math.min(budget,GameConfig.RETREAT_SECONDS); PathFinder.Result result=PathFinder.find(game.map,selected.x,selected.y,x,y,budget,game.occupiedExcept(selected),fastMove&&mode==Mode.MOVE,mode==Mode.RETREAT?GameConfig.RETREAT_MAX_CELLS:0); if(result==null){game.lastMessage="Destino no disponible: obstáculo, casilla ocupada o tiempo insuficiente.";previewPath=null;return;} previewPath=result.path; previewCost=result.cost; previewTarget=null; }
    private void button(String key) {
        if (animating && !key.equals("PAUSA") && !key.equals("CONTINUAR")) return;
        if(key.equals("REINICIAR")){game.reset();selected=null;mode=Mode.IDLE;previewPath=null;previewTarget=null;reachable.clear();invalidate();return;}
        if(key.equals("PAUSA")||key.equals("CONTINUAR")){paused=!paused;invalidate();return;}
        if(key.equals("CANCELAR")){previewPath=null;previewTarget=null;mode=Mode.IDLE;invalidate();return;}
        if(key.equals("RÁPIDO")||key.equals("RÁPIDO ✓")){fastMove=!fastMove;if(selected!=null)calculateReachable();invalidate();return;}
        if(key.equals("TERMINAR TURNO")){if(!paused&&game.activeSide==UnitModel.Side.PLAYER){previewPath=null;previewTarget=null;game.endPlayerTurn();if(selected!=null)calculateReachable();invalidate();}return;}
        if(selected==null||selected.side!=UnitModel.Side.PLAYER||game.activeSide!=UnitModel.Side.PLAYER||game.gameWon)return;
        if(key.equals("MOVER")){mode=Mode.MOVE;previewPath=null;previewTarget=null;calculateReachable();}
        else if(key.equals("ATACAR")){mode=Mode.ATTACK;previewPath=null;previewTarget=null;reachable.clear();game.lastMessage="Tocá una ficha enemiga dentro de alcance.";}
        else if(key.equals("REPLEGAR")){mode=Mode.RETREAT;previewPath=null;previewTarget=null;calculateReachable();}
        else if(key.equals("DEFENDER")){if(selected.defending){game.lastMessage="La defensa ya está activa para este turno.";}else if(selected.canSpend(GameConfig.DEFEND_SECONDS)){selected.spend(GameConfig.DEFEND_SECONDS);selected.defending=true;selected.actionState=UnitModel.ActionState.DEFENDING;game.lastMessage="Defensa activa: reduce el daño del próximo turno enemigo.";}else game.lastMessage="Tiempo insuficiente para defender.";}
        else if(key.equals("CONFIRMAR"))confirm();
        invalidate();
    }
    private void confirm() {
        if(selected==null)return;
        if(previewTarget!=null){if(GameState.distance(selected,previewTarget)>GameConfig.ATTACK_RANGE||!game.hasLineOfSight(selected,previewTarget)){game.lastMessage="Ataque inválido: fuera de alcance o sin visibilidad.";return;}if(!selected.canSpend(GameConfig.ATTACK_SECONDS)||selected.ammunition<=0||selected.attacksThisTurn>=1){game.lastMessage="Ataque no disponible: revisá tiempo, munición o límite de ataques.";return;}selected.spend(GameConfig.ATTACK_SECONDS);selected.ammunition--;selected.attacksThisTurn++;CombatEngine.Result result=game.combat.attack(selected,previewTarget);game.lastMessage=result.message+" (Probabilidad: "+result.chance+"%).";previewTarget=null;mode=Mode.IDLE;return;}
        if(previewPath==null||previewPath.isEmpty())return;
        UnitModel moving = selected; List<int[]> steps = new ArrayList<>(previewPath);
        if(mode==Mode.RETREAT){if(!selected.canSpend(GameConfig.RETREAT_SECONDS)){game.lastMessage="Tiempo insuficiente para replegarse.";return;}selected.spend(GameConfig.RETREAT_SECONDS);selected.fatigue=Math.min(100,selected.fatigue+GameConfig.FAST_FATIGUE);animateMovement(moving,steps,"Repliegue completado: "+steps.size()*GameConfig.METERS_PER_CELL+" m.");}
        else {if(previewCost>selected.timeRemaining){game.lastMessage="Tiempo insuficiente para ese movimiento.";return;}selected.spend(previewCost);if(fastMove){selected.fatigue=Math.min(100,selected.fatigue+GameConfig.FAST_FATIGUE);animateMovement(moving,steps,"Movimiento rápido completado. Fatiga +"+GameConfig.FAST_FATIGUE+".");}else animateMovement(moving,steps,"Movimiento completado.");}
        previewPath=null;mode=Mode.IDLE;reachable.clear();
    }

    private void animateMovement(final UnitModel moving, final List<int[]> steps, final String completionMessage) {
        animating = true; moving.actionState = UnitModel.ActionState.MOVING;
        final int[] index = {0};
        Runnable next = new Runnable() {
            @Override public void run() {
                if (index[0] < steps.size()) {
                    int[] cell = steps.get(index[0]++); moving.x = cell[0]; moving.y = cell[1]; invalidate(); postDelayed(this, 95);
                } else {
                    moving.actionState = moving.timeRemaining == 0 ? UnitModel.ActionState.EXHAUSTED : UnitModel.ActionState.READY;
                    animating = false; game.updateObjectives(); game.lastMessage = completionMessage; if (selected == moving) calculateReachable(); invalidate();
                }
            }
        };
        post(next);
    }
}
