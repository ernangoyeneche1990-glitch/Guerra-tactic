package com.tactica.guerra.rules;

import com.tactica.guerra.model.GameConfig;
import com.tactica.guerra.model.Terrain;
import java.util.*;

public class PathFinder {
    public static class Result {
        public final List<int[]> path;
        public final int cost;
        public Result(List<int[]> path, int cost) { this.path = path; this.cost = cost; }
    }
    private static final int[][] DIRS = {{1,0},{-1,0},{0,1},{0,-1}};

    public static Result find(GridMap map, int sx, int sy, int tx, int ty, int budget,
                              Set<String> occupied, boolean fast, int maxCells) {
        if (!map.passable(tx, ty) || (occupied != null && occupied.contains(key(tx, ty)))) return null;
        int[][] dist = new int[GameConfig.ROWS][GameConfig.COLUMNS];
        for (int[] row : dist) Arrays.fill(row, Integer.MAX_VALUE);
        int[][][] previous = new int[GameConfig.ROWS][GameConfig.COLUMNS][2];
        for (int y = 0; y < GameConfig.ROWS; y++) for (int x = 0; x < GameConfig.COLUMNS; x++)
            Arrays.fill(previous[y][x], -1);
        PriorityQueue<int[]> queue = new PriorityQueue<>(Comparator.comparingInt(a -> a[2]));
        dist[sy][sx] = 0; queue.add(new int[]{sx, sy, 0});
        while (!queue.isEmpty()) {
            int[] current = queue.poll(); int x = current[0], y = current[1];
            if (current[2] != dist[y][x]) continue;
            if (x == tx && y == ty) break;
            for (int[] d : DIRS) {
                int nx = x + d[0], ny = y + d[1];
                if (!map.passable(nx, ny) || (occupied != null && occupied.contains(key(nx, ny)) && !(nx == tx && ny == ty))) continue;
                int steps = Math.abs(nx - sx) + Math.abs(ny - sy);
                if (maxCells > 0 && steps > maxCells) continue;
                int terrain = GameConfig.terrainCost(map.terrainAt(nx, ny));
                int next = dist[y][x] + (fast ? Math.max(1, terrain * (100 - GameConfig.FAST_SPEED_BONUS_PERCENT) / 100) : terrain);
                if (next <= budget && next < dist[ny][nx]) {
                    dist[ny][nx] = next; previous[ny][nx][0] = x; previous[ny][nx][1] = y;
                    queue.add(new int[]{nx, ny, next});
                }
            }
        }
        if (dist[ty][tx] == Integer.MAX_VALUE) return null;
        List<int[]> path = new ArrayList<>(); int x = tx, y = ty;
        while (!(x == sx && y == sy)) { path.add(0, new int[]{x, y}); int px = previous[y][x][0], py = previous[y][x][1]; x = px; y = py; }
        return new Result(path, dist[ty][tx]);
    }
    public static String key(int x, int y) { return x + ":" + y; }
}
