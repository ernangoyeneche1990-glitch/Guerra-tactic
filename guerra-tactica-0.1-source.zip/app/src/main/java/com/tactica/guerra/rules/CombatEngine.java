package com.tactica.guerra.rules;

import com.tactica.guerra.model.GameConfig;
import com.tactica.guerra.model.UnitModel;
import java.util.Random;

public class CombatEngine {
    public static class Result {
        public final boolean success; public final int chance; public final double damage;
        public final String message;
        Result(boolean success, int chance, double damage, String message) {
            this.success = success; this.chance = chance; this.damage = damage; this.message = message;
        }
    }
    private final Random random = new Random();
    public Result attack(UnitModel attacker, UnitModel defender) {
        int chance = GameConfig.BASE_HIT_PERCENT;
        chance += attacker.morale >= 70 ? 5 : -10;
        chance += attacker.operationalCapacity < 50 ? -15 : 0;
        chance = Math.max(5, Math.min(95, chance));
        boolean success = random.nextInt(100) < chance;
        double damage = 0;
        if (success) {
            damage = GameConfig.MIN_DAMAGE_PERCENT + random.nextInt(GameConfig.MAX_DAMAGE_PERCENT - GameConfig.MIN_DAMAGE_PERCENT + 1);
            if (defender.defending) damage *= (100 - GameConfig.DEFENSE_REDUCTION_PERCENT) / 100.0;
            defender.operationalCapacity = Math.max(0, defender.operationalCapacity - damage);
        }
        String text = success ? "Ataque exitoso. Pérdida de capacidad enemiga: " + Math.round(damage) + "%." : "Ataque fallido.";
        return new Result(success, chance, damage, text);
    }
}
