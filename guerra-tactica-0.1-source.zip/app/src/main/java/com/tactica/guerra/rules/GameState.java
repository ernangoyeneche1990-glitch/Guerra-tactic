package com.tactica.guerra.rules;

import com.tactica.guerra.model.*;
import java.util.*;

public class GameState {
    public final GridMap map = new GridMap();
    public final List<UnitModel> units = new ArrayList<>();
    public final List<Objective> objectives = new ArrayList<>();
    public final CombatEngine combat = new CombatEngine();
    public int turn = 1;
    public UnitModel.Side activeSide = UnitModel.Side.PLAYER;
    public int playerConsecutiveControl = 0;
    public boolean gameWon = false;
    public String lastMessage = "Seleccioná una ficha para comenzar.";

    public GameState() { reset(); }
    public void reset() {
        units.clear(); objectives.clear(); turn = 1; activeSide = UnitModel.Side.PLAYER;
        playerConsecutiveControl = 0; gameWon = false;
        units.add(new UnitModel("P-01", "Grupo Tiradores 1", UnitModel.Side.PLAYER, "Tiradores", 8, 2, 12, "1.a Sección / Compañía A / Regimiento", "Avance"));
        units.add(new UnitModel("P-02", "Grupo Tiradores 2", UnitModel.Side.PLAYER, "Tiradores", 8, 4, 10, "1.a Sección / Compañía A / Regimiento", "Avance"));
        units.add(new UnitModel("P-03", "Grupo Tiradores 3", UnitModel.Side.PLAYER, "Tiradores", 8, 2, 14, "1.a Sección / Compañía A / Regimiento", "Reserva"));
        units.add(new UnitModel("P-04", "Grupo Apoyo 1", UnitModel.Side.PLAYER, "Apoyo", 12, 6, 12, "Compañía A / Regimiento", "Apoyo"));
        units.add(new UnitModel("E-01", "Grupo Enemigo 1", UnitModel.Side.ENEMY, "Tiradores", 8, 20, 3, "Fuerza enemiga / Batallón", "Defensa OBJ-03"));
        units.add(new UnitModel("E-02", "Grupo Enemigo 2", UnitModel.Side.ENEMY, "Tiradores", 8, 21, 11, "Fuerza enemiga / Batallón", "Defensa OBJ-02"));
        objectives.add(new Objective("OBJ-01", 12, 4)); objectives.add(new Objective("OBJ-02", 17, 9)); objectives.add(new Objective("OBJ-03", 8, 7));
        for (UnitModel unit : units) unit.resetTurn();
        updateObjectives();
    }
    public UnitModel unitAt(int x, int y) { for (UnitModel u : units) if (u.x == x && u.y == y && u.operationalCapacity > 0) return u; return null; }
    public UnitModel get(String id) { for (UnitModel u : units) if (u.id.equals(id)) return u; return null; }
    public Set<String> occupiedExcept(UnitModel ignored) {
        Set<String> set = new HashSet<>(); for (UnitModel u : units) if (u != ignored && u.operationalCapacity > 0) set.add(PathFinder.key(u.x, u.y)); return set;
    }
    public List<UnitModel> side(UnitModel.Side side) { List<UnitModel> out = new ArrayList<>(); for (UnitModel u : units) if (u.side == side) out.add(u); return out; }
    public int controlledByPlayer() { int count = 0; for (Objective o : objectives) if (o.control == Objective.Control.PLAYER) count++; return count; }
    public void updateObjectives() {
        for (Objective o : objectives) {
            boolean player = false, enemy = false;
            for (UnitModel u : units) if (u.x == o.x && u.y == o.y && u.operationalCapacity > 0) { if (u.side == UnitModel.Side.PLAYER) player = true; else enemy = true; }
            o.control = player && enemy ? Objective.Control.CONTESTED : player ? Objective.Control.PLAYER : enemy ? Objective.Control.ENEMY : Objective.Control.NEUTRAL;
        }
    }
    public void endPlayerTurn() {
        updateObjectives();
        if (controlledByPlayer() >= GameConfig.WIN_OBJECTIVES) playerConsecutiveControl++; else playerConsecutiveControl = 0;
        if (playerConsecutiveControl >= GameConfig.WIN_CONSECUTIVE_TURNS) { gameWon = true; lastMessage = "¡Victoria! Controlaste dos objetivos durante dos turnos."; return; }
        activeSide = UnitModel.Side.ENEMY; for (UnitModel e : side(activeSide)) e.resetTurn(); runEnemyTurn();
        activeSide = UnitModel.Side.PLAYER; turn++; for (UnitModel p : side(activeSide)) p.resetTurn(); updateObjectives();
        lastMessage = "Turno " + turn + ". Es tu turno.";
    }
    private void runEnemyTurn() {
        for (UnitModel enemy : side(UnitModel.Side.ENEMY)) {
            if (enemy.operationalCapacity <= 0) continue;
            UnitModel target = nearestEnemyTarget(enemy);
            if (target != null && distance(enemy, target) <= GameConfig.ATTACK_RANGE && hasLineOfSight(enemy, target)) {
                if (enemy.canSpend(GameConfig.ATTACK_SECONDS) && enemy.ammunition > 0) { enemy.spend(GameConfig.ATTACK_SECONDS); enemy.ammunition--; enemy.attacksThisTurn++; combat.attack(enemy, target); }
            } else {
                Objective objective = nearestObjective(enemy); if (objective != null) {
                    PathFinder.Result path = PathFinder.find(map, enemy.x, enemy.y, objective.x, objective.y, enemy.timeRemaining, occupiedExcept(enemy), false, 0);
                    if (path != null && !path.path.isEmpty()) { int[] end = path.path.get(path.path.size() - 1); enemy.x = end[0]; enemy.y = end[1]; enemy.spend(path.cost); }
                }
            }
        }
        updateObjectives();
    }
    private UnitModel nearestEnemyTarget(UnitModel from) { UnitModel best = null; int d = Integer.MAX_VALUE; for (UnitModel u : units) if (u.side != from.side && u.operationalCapacity > 0 && distance(from, u) < d) { best = u; d = distance(from, u); } return best; }
    private Objective nearestObjective(UnitModel from) { Objective best = null; int d = Integer.MAX_VALUE; for (Objective o : objectives) { int nd = Math.abs(from.x-o.x)+Math.abs(from.y-o.y); if (nd < d) { best=o; d=nd; } } return best; }
    public static int distance(UnitModel a, UnitModel b) { return Math.abs(a.x-b.x)+Math.abs(a.y-b.y); }
    public boolean hasLineOfSight(UnitModel a, UnitModel b) {
        int x = a.x, y = a.y, dx = Math.abs(b.x-a.x), sx = a.x < b.x ? 1 : -1, dy = -Math.abs(b.y-a.y), sy = a.y < b.y ? 1 : -1, err = dx + dy;
        while (!(x == b.x && y == b.y)) { int e2 = 2 * err; if (e2 >= dy) { err += dy; x += sx; } if (e2 <= dx) { err += dx; y += sy; } if (!(x == b.x && y == b.y) && map.terrainAt(x, y) == Terrain.BLOCKED) return false; }
        return true;
    }
}
