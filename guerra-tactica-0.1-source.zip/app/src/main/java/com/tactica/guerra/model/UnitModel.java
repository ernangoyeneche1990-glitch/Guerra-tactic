package com.tactica.guerra.model;

public class UnitModel {
    public enum Side { PLAYER, ENEMY }
    public enum ActionState { READY, MOVING, DEFENDING, EXHAUSTED }

    public final String id;
    public final String name;
    public final String type;
    public final Side side;
    public final int originalStrength;
    public int x, y;
    public double operationalCapacity = 100.0;
    public int fatigue = 0;
    public int morale = 100;
    public int ammunition = 5;
    public int timeRemaining = GameConfig.TURN_SECONDS;
    public int attacksThisTurn = 0;
    public boolean defending = false;
    public ActionState actionState = ActionState.READY;
    public String parentOrganization;
    public String mission;

    public UnitModel(String id, String name, Side side, String type, int strength,
                     int x, int y, String parentOrganization, String mission) {
        this.id = id; this.name = name; this.side = side; this.type = type;
        this.originalStrength = strength; this.x = x; this.y = y;
        this.parentOrganization = parentOrganization; this.mission = mission;
    }

    public boolean canSpend(int seconds) { return timeRemaining >= seconds && operationalCapacity > 0; }
    public void spend(int seconds) {
        timeRemaining = Math.max(0, timeRemaining - seconds);
        if (timeRemaining == 0) actionState = ActionState.EXHAUSTED;
    }
    public void resetTurn() {
        timeRemaining = GameConfig.TURN_SECONDS;
        attacksThisTurn = 0;
        defending = false;
        actionState = ActionState.READY;
    }
    public boolean isEnemyOf(UnitModel other) { return side != other.side; }
    public String sideLabel() { return side == Side.PLAYER ? "JUGADOR" : "ENEMIGO"; }
}
