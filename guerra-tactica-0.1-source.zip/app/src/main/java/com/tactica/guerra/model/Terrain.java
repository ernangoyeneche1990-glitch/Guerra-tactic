package com.tactica.guerra.model;

public enum Terrain {
    ROAD("Camino"), PLAIN("Llanura"), GRASS("Césped"), FOREST("Bosque"),
    HILL("Colina"), DIFFICULT("Difícil"), BLOCKED("Obstáculo");
    public final String label;
    Terrain(String label) { this.label = label; }
}
