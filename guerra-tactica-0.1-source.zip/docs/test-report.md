# Informe de pruebas 0.1

## Ejecutadas

`./scripts/run_model_checks.sh` está preparado para compilar las clases de modelo/reglas con `javac` y ejecutar 13 comprobaciones. En este entorno la ejecución terminó como `NO EJECUTADA: javac no está instalado`, por lo que no se reporta un resultado positivo ficticio.

Se verificaron costos configurables, movimiento ortogonal, bloqueo por obstáculo, presupuesto insuficiente, distancia de dos pasos sin diagonal directa, escenario inicial de 6 fichas y 3 objetivos, descuento/recarga temporal, límites de capacidad, defensa y control por ocupación.

## No ejecutadas

No se pudo compilar el APK ni instalarlo en Android: este entorno no contiene `gradle`, `adb` ni una ruta detectable de Android SDK. Por ese motivo no se declara prueba en teléfono. Tampoco fue posible ejecutar pruebas de interfaz, gestos, renderizado o rendimiento de dispositivo.

## Riesgos pendientes

Antes de distribuir la 0.1 hay que compilar con SDK 35, probar en al menos un teléfono horizontal, revisar tamaños de botones, y validar que la animación y el mapa mantengan rendimiento aceptable en el hardware objetivo.
