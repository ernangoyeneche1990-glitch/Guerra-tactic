# Documento técnico 0.1

## Arquitectura

- `MainActivity`: punto de entrada, fija orientación horizontal y monta la vista.
- `TacticalGameView`: renderizado 2D, selección táctil, arrastre/pellizco y controles.
- `GameState`: escenario, turnos, objetivos, IA básica y coordinación de reglas.
- `UnitModel`, `Objective`, `Terrain`, `GameConfig`: datos de dominio y configuración.
- `GridMap`, `PathFinder`: mapa lógico y búsqueda Dijkstra ortogonal con costos de terreno.
- `CombatEngine`: probabilidad, resultado, pérdida de capacidad y munición separados de la vista.

Cada unidad sigue siendo una ficha única. `originalStrength` conserva la dotación nominal (8 para tiradores, 12 para apoyo) y `operationalCapacity` acumula las pérdidas decimales sin crear soldados individuales. `parentOrganization` conserva la relación Grupo → Sección → Compañía → Regimiento para futuras versiones.

## Fórmulas de movimiento

`distancia = casillas recorridas × 20 m`.

El costo de una ruta es la suma del terreno de cada casilla de llegada: camino 20, llanura/césped 30, bosque/colina 45 y difícil 60 segundos. Los obstáculos son no transitables. Solo hay vecinos ortogonales.

El movimiento rápido aplica un costo del 50% y suma 20 puntos de fatiga. El repliegue limita la ruta a cinco casillas y consume 120 segundos.

## Combate

El ataque cuesta 60 s, tiene alcance Manhattan 3, requiere munición y está limitado a un ataque por ficha y turno. La probabilidad base es 60%, con ajustes simples por moral y capacidad. Un éxito aplica 5–15 puntos porcentuales de daño. Una ficha en defensa reduce ese daño en 20%; la defensa cuesta 60 s y no se acumula.

## Turnos e IA

Al terminar el turno del jugador se evalúa ocupación, se ejecuta un turno enemigo automático y se recarga el presupuesto del jugador. La IA ataca objetivos visibles dentro de alcance; en caso contrario busca el objetivo más cercano y avanza usando el mismo buscador de caminos. El control se actualiza por ocupación: jugador, enemigo, disputado o neutral. La victoria exige dos objetivos durante dos turnos consecutivos.

## Decisiones y límites conocidos

La primera versión usa gráficos vectoriales de reemplazo para que el APK no dependa de arte externo. El movimiento se anima como actualización de posición al confirmar; el siguiente incremento puede interpolar paso a paso. No se incluyeron persistencia de campaña, selección múltiple, fuego indirecto, balística, sonido ni guardado de partidas. La exportación Android no fue posible en el entorno actual por ausencia comprobada del SDK y Gradle.
