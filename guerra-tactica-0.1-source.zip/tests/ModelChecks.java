import com.tactica.guerra.model.*;
import com.tactica.guerra.rules.*;

/** Pruebas rápidas sin Android SDK para los límites de movimiento y estado. */
public final class ModelChecks {
    private static int checks = 0;
    private static void check(boolean value, String name) { checks++; if (!value) throw new AssertionError(name); }
    public static void main(String[] args) {
        GridMap map = new GridMap();
        check(GameConfig.terrainCost(Terrain.ROAD) == 20, "costo de camino");
        check(GameConfig.terrainCost(Terrain.FOREST) == 45, "costo de bosque");
        check(!map.passable(9, 5), "obstáculo bloqueado");
        PathFinder.Result road = PathFinder.find(map, 1, 7, 4, 7, 60, null, false, 0);
        check(road != null && road.path.size() == 3 && road.cost == 60, "distancia y costo ortogonal");
        PathFinder.Result tooFar = PathFinder.find(map, 1, 7, 6, 7, 60, null, false, 0);
        check(tooFar == null, "presupuesto insuficiente");
        PathFinder.Result diagonalShortcut = PathFinder.find(map, 1, 7, 2, 8, 60, null, false, 0);
        check(diagonalShortcut != null && diagonalShortcut.path.size() == 2, "sin diagonal de un paso");

        GameState state = new GameState();
        check(state.units.size() == 6 && state.objectives.size() == 3, "escenario inicial");
        UnitModel player = state.get("P-01");
        int before = player.timeRemaining;
        PathFinder.Result move = PathFinder.find(state.map, player.x, player.y, 2, 11, before, state.occupiedExcept(player), false, 0);
        check(move != null, "ruta de unidad inicial");
        player.spend(move.cost); check(player.timeRemaining == before - move.cost, "descuento de tiempo");
        player.resetTurn(); check(player.timeRemaining == GameConfig.TURN_SECONDS, "recarga por turno");
        UnitModel enemy = state.get("E-01");
        CombatEngine.Result result = state.combat.attack(player, enemy);
        check(enemy.operationalCapacity <= 100 && enemy.operationalCapacity >= 0, "capacidad acotada");
        enemy.defending = true; state.combat.attack(player, enemy);
        check(enemy.operationalCapacity >= 0, "defensa no produce valores inválidos");
        state.reset(); state.get("P-01").x = state.objectives.get(0).x; state.get("P-01").y = state.objectives.get(0).y;
        state.updateObjectives(); check(state.objectives.get(0).control == Objective.Control.PLAYER, "control por ocupación");
        System.out.println("OK: " + checks + " comprobaciones de modelo");
    }
}
