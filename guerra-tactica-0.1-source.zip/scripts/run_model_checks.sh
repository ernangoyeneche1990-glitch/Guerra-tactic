#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="$(mktemp -d)"
trap 'rm -rf "$OUT"' EXIT
if ! command -v javac >/dev/null 2>&1; then
  echo "NO EJECUTADA: javac no está instalado en este entorno." >&2
  exit 2
fi
javac -d "$OUT" $(find "$ROOT/app/src/main/java/com/tactica/guerra/model" "$ROOT/app/src/main/java/com/tactica/guerra/rules" -name '*.java') "$ROOT/tests/ModelChecks.java"
java -cp "$OUT" ModelChecks
